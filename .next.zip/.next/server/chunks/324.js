"use strict";
exports.id = 324;
exports.ids = [324];
exports.modules = {

/***/ 7797:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5675);


const Footer = ()=>{
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "footer",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "footer-container",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                    href: "https://goo.gl/maps/gau94booSoe9dDGB9",
                    "aria-label": "location link",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "location flex",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_image__WEBPACK_IMPORTED_MODULE_1__["default"], {
                                src: "/Images/icons8-location-50.png",
                                alt: "location",
                                width: 30,
                                height: 30
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                children: "ساری _خیابان شهابی _خیابان المهدی"
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "socials flex",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                            href: "https://www.instagram.com/sarisartel2/",
                            "aria-label": "instagram link",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_image__WEBPACK_IMPORTED_MODULE_1__["default"], {
                                src: "/Images/icons8-instagram-30.png",
                                alt: "instagram logo",
                                width: 35,
                                height: 35
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                            href: "tel:01133201111",
                            "aria-label": "telephone number",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_image__WEBPACK_IMPORTED_MODULE_1__["default"], {
                                src: "/Images/icons8-ringer-volume-50.png",
                                alt: "telephone",
                                id: "telephone",
                                width: 30,
                                height: 30
                            })
                        })
                    ]
                })
            ]
        })
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Footer);


/***/ }),

/***/ 9446:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ Layout_Header)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(968);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./node_modules/next/dist/client/link.js
var client_link = __webpack_require__(8418);
;// CONCATENATED MODULE: ./components/Layout/BurgerMenu.jsx



const BurgerMenu = ()=>{
    const { 0: isLoggedIn , 1: SetIsLoggedIn  } = (0,external_react_.useState)(false);
    function closenav() {
        document.getElementById("myNav").style.width = "0%";
    }
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        id: "myNav",
        className: "overlay",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                href: "#",
                className: "closebtn",
                onClick: closenav,
                "aria-label": "close button",
                children: "\xd7"
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "overlay-content",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(client_link["default"], {
                        href: "/",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                            id: "home-tag",
                            "aria-label": "home",
                            children: " خانه"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(client_link["default"], {
                        href: "/about",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                            id: "about-tag",
                            "aria-label": "about us",
                            children: " درباره ما"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(client_link["default"], {
                        href: "/suggestions",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                            id: "sug-tag",
                            "aria-label": "suggestions",
                            children: " نظرات و پیشنهادات"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(client_link["default"], {
                        href: "/products/محصولات",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                            id: "prod-tag",
                            "aria-label": "products",
                            children: " محصولات"
                        })
                    })
                ]
            })
        ]
    }));
};
/* harmony default export */ const Layout_BurgerMenu = (BurgerMenu);

// EXTERNAL MODULE: ./node_modules/next/dist/client/image.js
var client_image = __webpack_require__(8045);
;// CONCATENATED MODULE: ./components/Layout/Header.jsx





const Header = ()=>{
    function opennav(e) {
        e.preventDefault();
        document.getElementById("myNav").style.width = "100%";
        document.getElementById("myNav").style.height = "100%";
    }
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "header",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((head_default()), {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        charSet: "utf-8"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        httpEquiv: "X-UA-Compatible",
                        content: "IE=edge"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        name: "viewport",
                        content: "width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=5"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        name: "description",
                        content: "مرکز فروش و خدمات مجاز گوشی های همراه (شیائومی, هواوي, نوكيا, سامسونگ)"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        name: "keywords",
                        content: "samsung apple huawei xiaomi"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "upper-header",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(Layout_BurgerMenu, {}),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "login-search",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                href: "/user/login",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    "aria-label": "login",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                        children: "ورود"
                                    })
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                type: "text",
                                placeholder: "جستجو..."
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "header-logo",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                href: "/",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    "aria-label": "home",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(client_image["default"], {
                                        src: "/Images/logo-removebg-preview.png",
                                        alt: "sari sartel's logo",
                                        width: 108,
                                        height: 40
                                    })
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                href: "#",
                                onClick: opennav,
                                "aria-label": "open navigation",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(client_image["default"], {
                                    src: "/Images/burger-menu.png",
                                    alt: "burger menu",
                                    id: "burger-menu",
                                    width: 40,
                                    height: 40
                                })
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "down-header",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                        href: `/`,
                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                            "aria-label": "home",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "header-item",
                                id: "home-h",
                                children: "خانه"
                            })
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "dropdown-prod",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                href: `/products/محصولات`,
                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    "aria-label": "products",
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "header-item",
                                        id: "prod-h",
                                        children: [
                                            "محصولات",
                                            /*#__PURE__*/ jsx_runtime_.jsx(client_image["default"], {
                                                src: "/Images/icons8-sort-down-24.png",
                                                width: 24,
                                                height: 24,
                                                alt: "down button"
                                            })
                                        ]
                                    })
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "dropdown",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "dropdown-content",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                                href: "/products/تلفن همراه",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                    "aria-label": "cell phones",
                                                    children: "تلفن همراه"
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                                href: "/products/تبلت",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                    "aria-label": "tablet",
                                                    children: "تبلت"
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                                href: "/products/ساعت هوشمند",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                    "aria-label": "smart watches",
                                                    children: "ساعت هوشمند"
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                                href: "/products/لوازم جانبی",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                    "aria-label": "accessories",
                                                    children: "لوازم جانبی"
                                                })
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "dropdown-content2",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                                href: "/products/اپل",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                    "aria-label": "apple",
                                                    children: "اپل"
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                                href: "/products/سامسونگ",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                    "aria-label": "samsung",
                                                    children: "سامسونگ"
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                                href: "/products/هواوی",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                    "aria-label": "huawei",
                                                    children: "هواوی"
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                                href: "/products/شیائومی",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                    "aria-label": "xiaomi",
                                                    children: " شیائومی"
                                                })
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                        href: `/about`,
                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                            "aria-label": "about-us",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "header-item",
                                id: "about-h",
                                children: "درباره ما"
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                        href: `/suggestions`,
                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                            "aria-label": "suggestions",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "header-item",
                                id: "sug-h",
                                children: "نظرات و پیشنهادات"
                            })
                        })
                    })
                ]
            })
        ]
    }));
};
/* harmony default export */ const Layout_Header = (Header);


/***/ })

};
;